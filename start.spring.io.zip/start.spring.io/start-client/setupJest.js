//setupJest.js or similar file
global.fetch = require('jest-fetch-mock')
