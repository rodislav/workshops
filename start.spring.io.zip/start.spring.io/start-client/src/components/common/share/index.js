export { default as Share } from './Share'
